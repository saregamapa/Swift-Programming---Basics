//: Playground - noun: a place where people can play

import UIKit

//: VARIABLES

var str = "Hello, World!";

var myNumber = 3;

var myNumber1 : Int = 3;

var myNumber2 : Int = 4;

var str1 : String = "Hello Swift!";

var exampleStr : String = "Hi There!!"

var exampleStr2 : String = "H1B sucks"

var exampleStr3 : String = "412"

var realDream : String = "US Greencard in this June"

var realDream2 : String = "My Company starts in this July"

var realGoal : String = "Dream comes true"

var realAchievement : String = "Awesome Sonali"

var realAchievement2 : String = "I am genius"

var realDreaminNumber : Int = 2

//: FLOAT AND DOUBLE

var myDouble : Double = 3.14565667

var myFloat : Float = 4.53433243245345

var myDouble2 : Double = 4.53433243245345

var myDouble3 : Double = 100.12239834950345820

var myDouble4 : Double = 13.2324234983470

var myFloat4 : Float = 23.34324

//: BOOLEAN

var myBoolean : Bool = true

var myBoolean2 : Bool = false

//: ARRAY

var myArray : [String] = ["Tea", "Coffee", "Coco", "GreenTea", "Chocolate"]

myArray[0]

myArray[4] = "Cola"

myArray[4]

myArray.remove(at : 3)

myArray

myArray.append("IceTea")

myArray.remove(at : 2)

myArray

var myIntArray = [Int] ()

var myInt : [Int] = [1,2,3,4,5]

myInt.remove(at : 3)

myInt

myInt.append(6)

myInt.remove(at : 0)

myInt

//: DICTIONARY

var examResults = ["Maths" : 8, "Physics" : 9, "Chemistry" : 10, "Programming" : 11]

examResults["Physics"]

examResults["Maths"]

examResults["Programming"]

examResults.removeValue(forKey: "Chemistry")

//: SET

var fruits : Set<String> = ["Strawberry", "Banana", "Pineapple", "Mango", "Peach"]

fruits.insert("Orange")

fruits

fruits.remove("Banana")

fruits

fruits.insert("Peach")

fruits

//: OPTIONALS AND CONSTANTS


var initialName : String = "JOHN"

var middleName : String?

var surName : String = "DOE"

print(initialName)

middleName = "RAN"
//: print(middleName)

print(surName)

print(initialName)

//: OPTIONAL WRAPPED
middleName = "RAN"
print(middleName!)

print(surName)


var firstName : String = "Sonali"

var lastName : String?

print(firstName)

lastName = "Mehta"
//: print(lastName)

print(lastName!)

//: CONSTANTS

let SPEED_LIMIT_MWAY = 70

let SPEED_LIMIT_RD = 20

print(" Speed limit in motorways is \(SPEED_LIMIT_MWAY) , speed limit in roads with traffic lights is \(SPEED_LIMIT_RD)")


let AGE = 27

print(" My age is \(AGE)")

//: LOGICAL EXPRESSIONS

//: IF... ELSE

var myNum1 = 20

var myNum2 = 20

if (myNum1 == myNum2) {
    
    print("These numbers are equal.")
}
else if (myNum1 < myNum2) {
    
    print ("myNum1 is less than myNum2.")
    
}
else {
    print("myNum1 is greater than myNum2.")
}

//: SWITCH... CASE

    var temperature = 35

    switch temperature {
        
    case -40..<0:
          print ("Its very cold")
    case 0..<15:
         print ("Its cold.")
    case 15..<30:
        print ("Its nice.")
    case 30..<60:
        print ("Its hot")
    default:
        print("Its either too cold or too hot.")
    }


var myChoice = 1

switch myChoice {
    
case 0:
    print ("Choice is 0.")
case 1:
    print ("Choice is 1.")
case 2:
    print("Choice is 2.")
default:
    print("There is no myChoice.")
}

var sum=0

for counter in 1...20 {
    sum = sum + counter;
}
print(sum)

var prillo=3

for zillo in 1...5 {
    prillo = prillo * zillo;
}
print (prillo)


var myArr: [Character] = ["s", "w", "i", "f", "t"]

for myChar in myArr {
    print(myChar)
}

var Counter1 = 2
var sum1 = 0

while Counter1 < 5 {
    Counter1 = Counter1 + 1
    sum1 = sum1 + Counter1
    
}
print(sum1)

//: FUNCTIONS


func repeatLoop() {
    
    var myCharArr: [Character] = ["S", "U", "N"]

    for myChar1 in myCharArr {
        print (myChar1)
    }

}

repeatLoop()
repeatLoop()

func printTax (priceBeforeTax : Double) {
    var priceAfterTax : Double = priceBeforeTax * 1.10
    print(priceAfterTax)
}

printTax(priceBeforeTax : 100)
printTax(priceBeforeTax : 20.23)

func printTax (priceBeforeTax : Double, taxRate : Double) -> Double {
    var priceAfterTax : Double = priceBeforeTax * (1 + taxRate/100)
    return (priceAfterTax)
}

printTax(priceBeforeTax : 100, taxRate : 7)
printTax(priceBeforeTax : 20.23, taxRate : 4)

//: CLASS

class Car {
    var colour: String
    
    init (colour:String) {
        self.colour = colour

    }
    
    func askColour() -> String {
        return self.colour
    }
}

var myCar = Car (colour : "red")

var yourCar = Car (colour : "White")

print(myCar.askColour())
print(yourCar.askColour())

class hatchBackCar:Car {
    var length = "Short"
}

var myNewCar = hatchBackCar (colour: "Black")
print(myNewCar.askColour())
print(myNewCar.length)
